This plugin contains the Zinari Plugin for woocommerce. This enables you receive payments in cryptocurrencies, on your wordpress website using Woocommerce.
The plugin is built by Zinari Finance, in collaboration with Saltwaterlabs.io.

