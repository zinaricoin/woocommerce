<?php
/*
Plugin Name: Zinari Cryptocurrency Gateway for WooCommerce
Plugin URI: https://forgingblock.io/
Description: Zinari Cryptocurrency Gateway for WooCommerce
Version: 2.1.2
Author: dev@forgingblock.io
Author URI: https://api.zinaricoin.com/docs/#integrations-woocommerce
WC requires at least: 3.0
WC tested up to: 4.4.1
License: Copyright (c) 2019-2021 Forging Technologies, Inc. MIT license
 */

add_action('plugins_loaded', 'woocommerce_forgingblock_init', 0);

function woocommerce_forgingblock_init() {
    if ( !class_exists( 'WC_Payment_Gateway' ) ) return; 
    load_plugin_textdomain('wc-forgingblock', false, dirname( plugin_basename( __FILE__ ) ) . '/languages');    
	
    /**
     * Localisation
     */

    if($_GET['spmsg']!=''){
        add_action('the_content', 'showMessage_forgingblock');
    }
	
    function showMessage_forgingblock($content){
            return '<ul class="woocommerce-error"><li>'.htmlentities(urldecode($_GET['spmsg'])).'</ul>'.$content;
    }

    /**
     * Gateway class
     */

    class WC_Zinari extends WC_Payment_Gateway {

    protected $spmsg = array();

        public function __construct(){
            $this -> id = 'forgingblock';
            $this -> method_title = __('Zinari', 'forgingblock');
            $this -> icon = '';
            $this -> has_fields = false;
            $this -> init_form_fields();
            $this -> init_settings();
            $this -> title = $this -> settings['title'];
            $this -> description = $this -> settings['description'];
			$this -> method_description = 'Zinari Gateway for Woocommerce (using  <a href="https://forgingblock.io/">Forging Block API</a>) allows you to accept cryptocurrency payments on your WooCommerce store';
            $this -> trade_id = $this -> settings['trade_id'];
			$this -> token = $this -> settings['token'];			
			$this -> environment = $this -> settings['environment'];
			$this -> currency_code = get_woocommerce_currency();
            $this -> spmsg['message'] = "";
            $this -> spmsg['class'] = "";

            add_action('valid-forgingblock-request', array(&$this, 'successful_request'));				

          	if ( version_compare( WOOCOMMERCE_VERSION, '3.0.0', '>=' ) ) {
                add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( &$this, 'process_admin_options' ) );
             } else {
                add_action( 'woocommerce_update_options_payment_gateways', array( &$this, 'process_admin_options' ) );
            } 		
			
            add_action( 'woocommerce_api_' . strtolower( get_class( $this ) ), array( $this, 'check_forgingblock_response' ) );	
        }



        function init_form_fields(){	
			$env_list =  array('test'=>'Test', 'live' => 'Live');	

            $this -> form_fields = array(

                'enabled' => array(
                    'title' => __('Enable/Disable', 'forgingblock'),
                    'type' => 'checkbox',
                    'label' => __('Enable Zinari Payment Module.', 'forgingblock'),
                    'default' => 'no'),

                'title' => array(
                    'title' => __('Title:', 'forgingblock'),
                    'type'=> 'text',
                    'description' => __('This controls the title which the user sees during checkout.', 'forgingblock'),
                    'default' => __('Zinari', 'forgingblock')),

                'description' => array(
                    'title' => __('Description:', 'forgingblock'),
                    'type' => 'textarea',
                    'description' => __('This controls the description which the user sees during checkout.', 'forgingblock'),
                    'default' => __('Pay securely by Zinari.', 'forgingblock')),				

				'trade_id' => array(
                    'title' => __('Trade ID', 'forgingblock'),
                    'type' => 'text',
                    'description' => __('Enter Trade ID Given by Zinari')),					

 				'token' => array(
                    'title' => __('Token', 'forgingblock'),
                    'type' => 'text',
                    'description' => __('Enter Token Given by Zinari')),	
				
				'environment' => array(
					'title'       => __( 'Environment', 'forgingblock' ),
					'type'        => 'select',
					'default'     => 'test',										
					'description' => '',
					'options'     => $env_list,
				),

				
				'new_status' => array(
					'title'       => __( 'New status', 'forgingblock' ),
					'type'        => 'select',
					'default'     => 'wc-pending',										
					'description' => '',
					'options'     => wc_get_order_statuses(),
				),
				
				'paid_status' => array(
					'title'       => __( 'Paid status', 'forgingblock' ),
					'type'        => 'select',
					'default'     => 'wc-processing',										
					'description' => '',
					'options'     => wc_get_order_statuses(),
				),
				
				'confirmed_status' => array(
					'title'       => __( 'Confirmed status', 'forgingblock' ),
					'type'        => 'select',
					'default'     => 'wc-processing',										
					'description' => '',
					'options'     => wc_get_order_statuses(),
				),			
								
				'complete_status' => array(
					'title'       => __( 'Complete status', 'forgingblock' ),
					'type'        => 'select',
					'default'     => 'wc-processing',										
					'description' => '',
					'options'     => wc_get_order_statuses(),
				),
				
				'expired_status' => array(
					'title'       => __( 'Expired status', 'forgingblock' ),
					'type'        => 'select',
					'default'     => 'wc-failed',										
					'description' => '',
					'options'     => wc_get_order_statuses(),
				),
				
				'invalid_status' => array(
					'title'       => __( 'Expired status', 'forgingblock' ),
					'type'        => 'select',
					'default'     => 'wc-failed',										
					'description' => '',
					'options'     => wc_get_order_statuses(),
				),              		
           );
        }

        /**
         * Admin Panel Options
         * - Options for bits like 'title' and availability on a country-by-country basis
         **/

        public function admin_options(){

            echo '<h3>'.__('Zinari Payment Gateway', 'forgingblock').'</h3>';
            echo '<p>'.__('Zinari is most popular payment gateway').'</p>';
            echo '<table class="form-table">';
            $this -> generate_settings_html();
            echo '</table>';
        }

		 

        function payment_fields(){			
			 if($this -> description) echo wpautop(wptexturize($this -> description));
        }

		
        /**

         * Process the payment and return the result

         **/

        function process_payment($order_id){

			global $woocommerce;

            $order = new WC_Order($order_id);			
			$amount = $order->calculate_totals();						
			
			$notifyURL  = add_query_arg( 'wc-api', get_class( $this ), home_url('/') );
			$notifyURL = add_query_arg(array('orderid' => $order_id), $notifyURL);
			$returnURL = $this->get_return_url( $order );				
			
			
			require_once(dirname(__FILE__) . '/lib/Forgingblock.php');	
			
			$forgingblock = new Forgingblock($this -> environment);
			$forgingblock->SetValue('trade',  $this -> trade_id);
			$forgingblock->SetValue('token', $this -> token);
			$forgingblock->SetValue('amount', round($amount, 2));								
			$forgingblock->SetValue('currency', $this -> currency_code);		
			$forgingblock->SetValue('link', $returnURL);
			$forgingblock->SetValue('notification', $notifyURL);
			$forgingblock->SetValue('order', $order_id);
			$resar = $forgingblock->CreateInvoice();				
			$Error = $forgingblock->GetError();		
			
			if ($Error) {				
				wc_add_notice( __( 'Gateway request failed - '.$Error, 'woocommerce' ) ,'error');	
          		return array('result' => 'failed');
			}
			else {
				$paymenturl = $forgingblock->GetInvoiceURL();
				$InvoiceID = $forgingblock->GetInvoiceID();	
				update_post_meta($order_id, 'InvoiceID', $InvoiceID );	
				return array('result' => 'success', 'redirect' => $paymenturl);				
			}	
			
        }

	

//call back	

        function check_forgingblock_response(){
			global $woocommerce, $wpdb;
			
           if($_GET['wc-api']== get_class( $this )){
			   $order_id = $_GET['orderid'];				   
			   $order = new WC_Order($order_id);		
				$invoice_id  = get_post_meta($order_id, 'InvoiceID',  true);
			   
				
				require_once(dirname(__FILE__) . '/lib/Forgingblock.php');	
				
				$forgingblock = new Forgingblock($this -> environment);
				$forgingblock->SetValue('trade',  $this -> trade_id);
				$forgingblock->SetValue('token', $this -> token);	
				$forgingblock->SetValue('invoice', $invoice_id);		
		
			   $resar = $forgingblock->CheckInvoiceStatus();
		
			   $payment_status = $forgingblock->GetInvoiceStatus();
			   
		
			   if (isset($payment_status)) {			
				   $status_id = $payment_status.'_status';				   
				   $status = $this->settings[$status_id];
  			     	$order->update_status($status, __('Payment Status - '.$payment_status, 'forgingblock'));
				 
				}
				else {					
					$order->update_status('failed', __('Payment Fail - Unknown Payment Status', 'forgingblock'));
					return ;
				}
			     echo "OK";
				 exit;
				

		  }
        }								
	}

	

    /**

     * Add the Gateway to WooCommerce

     **/

    function woocommerce_add_forgingblock_gateway($methods) {

        $methods[] = 'WC_Zinari';

        return $methods;

    }

    add_filter('woocommerce_payment_gateways', 'woocommerce_add_forgingblock_gateway' );
	
	add_filter('plugin_action_links', 'forgingblock_plugin_action_links', 10, 2);

    function forgingblock_plugin_action_links($links, $file)
    {
        static $this_plugin;

        if (false === isset($this_plugin) || true === empty($this_plugin)) {
            $this_plugin = plugin_basename(__FILE__);
        }

        if ($file == $this_plugin) {            
            $settings_link = '<a href="' . get_bloginfo('wpurl') . '/wp-admin/admin.php?page=wc-settings&tab=checkout&section=forgingblock">Settings</a>';   array_unshift($links, $settings_link);
        }

        return $links;
    }	

  }
?>